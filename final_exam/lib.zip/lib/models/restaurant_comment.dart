


class Comment {
  final int star;
  final String feedback;

  Comment({
    required this.star,
    required this.feedback,
  });
}
